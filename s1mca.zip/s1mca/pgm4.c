
#include <stdio.h>
void main()
{
    int a[5][5],b[5][5],c[10][10],m,n,p,q,i,j,ch,r;
    printf("enter size of matrix1\n");
    scanf("%d%d",&m,&n);
    printf("enter size of matrix2\n");
    scanf("%d%d",&p,&q);
    printf("enter elements of matrix1");
    for(i=0;i<m;++i)
    {
        for(j=0;j<n;++j)
            scanf("%d",&a[i][j]);
    }
    printf("enter elements of matrix2");
    for(i=0;i<p;++i)
    {
        for(j=0;j<q;++j)
            scanf("%d",&b[i][j]);
    }
    do{
    printf("1.addition\n2.subtraction\n3.multiplication\nenter choice\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:if((m==p)&&(n==q))
                {
                    for(i=0;i<m;++i)
                    {
                        for(j=0;j<n;++j)
                        {
                            c[i][j]=a[i][j]+b[i][j];
                            printf("%d ",c[i][j]);
                        }
                        printf("\n");
                    }
                }
                else
                 printf("cannot add");
                break;
        case 2:if((m==p)&&(n==q))
                {
                    for(i=0;i<m;++i)
                    {
                        for(j=0;j<n;++j)
                        {
                            c[i][j]=a[i][j]-b[i][j];
                            printf("%d ",c[i][j]);
                        }
                        printf("\n");
                    }
                }
                else
                 printf("cannot add");
                break;
        case 3: if(n==p)
                {
                for (i = 0; i < m; ++i) {
                for (j = 0; j < q; ++j) {
                    c[i][j] = 0;
                    for (int k = 0; k < n; ++k) {
                        c[i][j] += a[i][k] * b[k][j];
                    }
                    printf("%d ", c[i][j]);
                }
                printf("\n");
                }
                }
                else
                printf("cannot multilply");
             break;
        default:printf("inavlid");
    }
    printf("execute more\n");
    scanf("%d",&r);
    }while(r!=0);
}

