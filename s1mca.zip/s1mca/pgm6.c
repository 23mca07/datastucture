#include<stdio.h>
#define n 50
int a[n],f=-1,r=-1;
void insert()
{
if(r==n-1)
{
printf("queue overflow");
}
else
{
if(f==-1){
f=r=0;
}
else{
r++;}
printf("enter element to be inserted:");
scanf("%d",&a[r]);
}
}
void del()
{
if(f==-1)
{
printf("queue underflow");
}
else{
printf("%d is deleted",a[f]);
if(f==r){
r=f=-1;}
else{
f++;
}}}
  void display(){
  if(f==-1){
  printf("queue underflow");
  }
  else{
  for(int i=f;i<r;i++){
  printf("%d",a[i]);
  }}}
  
  void main(){
  int ch;
  do
  {
  printf("\n1.insert \n2.delete \n3.display\n 4.exit .\nenter your choice");
  scanf("%d",&ch);
  
  switch(ch)
  {
  case1:insert();
  break;
  case 2:del();
  break;
  case 3:
  display();
  break;
  case 4:
  
  break;
  default:printf("invalid choice");
 
  break;}
  }
  while(ch>0&&ch<5);
}
  
