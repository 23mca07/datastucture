#include<stdio.h>
void swap(int a,int b)
{
int temp;
temp=a;
a=b;
b=temp;
printf("swapped numbers are %d and %d\n",a,b);
}
void main()
{
int a,b;
printf("enter 1 numbers:");
scanf("%d",&a);
printf("enter second number:");
scanf("%d",&b);
printf("before swapping %d and %d\n",a,b);
swap(a,b);

}
